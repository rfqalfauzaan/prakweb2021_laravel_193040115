

<?php $__env->startSection('container'); ?>

<article>
<h1 class = "mb-5"><?php echo e($post->title); ?></h1>
<p>By. Amisha Al azis in <a href="/categories/<?php echo e($post->category->slug); ?>"> <?php echo e($post->category->name); ?></a></p>

<h5><?php echo e($post->author); ?></h5>

<?php echo $post->body; ?>

</article>

<a href="/blog">Back to Posts</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\amish\Documents\Mata Kuliah\Semester 5\Praktikum Web\application\coba-laravel\resources\views/post.blade.php ENDPATH**/ ?>