

<?php $__env->startSection('container'); ?>
<h1>Halaman Home</h1>
<?php $__env->stopSection(); ?>    
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Kuliah\Semester 5\PW\prakweb2021_laravel_193040115\coba-laravel\resources\views/home.blade.php ENDPATH**/ ?>